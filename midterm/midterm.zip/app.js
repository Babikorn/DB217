let mark = [
  [0, 0, 0, 0],
  [0, 0, 0, 0],
  [0, 0, 0, 0],
  [0, 0, 0, 0],
];
let black = 0;

function summary() {
  // เพิ่มคำสั่งที่นี่
}

function flip(pawn) {
  // เพิ่มคำสั่งที่นี่
}

function main() {
  // เพิ่มคำสั่งที่นี่
  summary();
}

main();
